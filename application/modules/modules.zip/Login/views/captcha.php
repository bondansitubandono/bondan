<?php echo form_open('login/auth'); ?>
        
    <?php echo form_close(); ?>