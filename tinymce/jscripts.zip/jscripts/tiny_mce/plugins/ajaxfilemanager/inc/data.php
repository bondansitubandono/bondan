<pre>Array
(
    [currentFolderPath] => ../../../../uploaded/
    [new_folder] => Gambar 1
)
</pre>

01/Feb/2016 05:24:01